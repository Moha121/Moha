package com.example.myapplicationghg

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import java.io.File

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
AudioFragment.k

private val mAudioFilePath = Environment.getExternalStoragePublicDirectory(
    Environment.DIRECTORY_MUSIC).path + File.separator + "sample_audio.mp3"
private lateinit var mAudioFileUri: Uri
private val mRecordAudioIntent = Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION)

override fun onClick(view: View) {
    val mStarted
    when (view.id) {
        R.id.buttonAudioStart -> if (!mStarted) {
            val musicIntent = Intent(activity?.applicationContext,
                MediaPlaybackService::class.java)
            musicIntent.putExtra("URIString", mAudioFileUri.toString())
            activity?.startService(musicIntent)
            mStarted = true }
        R.id.buttonAudioStop -> {
            activity?.stopService(Intent(activity?.applicationContext,
                MediaPlaybackService::class.java))
            mStarted = false }
        R.id.buttonAudioRecord -> startActivityForResult(mRecordAudioIntent,AUDIO_CAPTURED)
    }
}


override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    if (resultCode == RESULT_OK && requestCode == AUDIO_CAPTURED) {
        if (data != null) {
            mAudioFileUri = data.data }
    }
}